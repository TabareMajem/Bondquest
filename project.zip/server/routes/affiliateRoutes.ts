import { Router } from 'express';
import { storage } from '../storage';
import { z } from 'zod';
import { 
  insertAffiliatePartnerSchema, 
  insertAffiliateCouponSchema, 
  insertAffiliateReferralSchema,
  insertAffiliateTransactionSchema,
  insertAffiliatePaymentSchema
} from '@shared/schema';
import { nanoid } from 'nanoid';
import bcrypt from 'bcrypt';

// Authentication check middleware
const isAuthenticated = (req: any, res: any, next: any) => {
  if (req.isAuthenticated()) {
    return next();
  }
  return res.status(401).json({ message: 'Unauthorized' });
};

// Admin check middleware
const isAdmin = (req: any, res: any, next: any) => {
  if (req.isAuthenticated() && req.user && (req.user.role === 'admin' || req.user.username === 'admin')) {
    return next();
  }
  return res.status(403).json({ message: 'Forbidden: Admin access required' });
};

// Affiliate Partner check middleware
const isAffiliatePartner = async (req: any, res: any, next: any) => {
  // If user is already admin, allow access
  if (req.isAuthenticated() && req.user && (req.user.role === 'admin' || req.user.username === 'admin')) {
    return next();
  }
  
  // Check if the request has a valid affiliate partner authorization
  const email = req.body.email || req.query.email;
  const partnerId = req.params.partnerId || req.body.partnerId || req.query.partnerId;
  
  if (!email && !partnerId) {
    return res.status(400).json({ message: 'Missing partner identification' });
  }
  
  let partner;
  
  if (partnerId) {
    partner = await storage.getAffiliatePartner(parseInt(partnerId));
  } else if (email) {
    partner = await storage.getAffiliatePartnerByEmail(email);
  }
  
  if (!partner || partner.status !== 'active') {
    return res.status(403).json({ message: 'Forbidden: Active affiliate partner access required' });
  }
  
  // Set the partner for use in the route handler
  req.affiliatePartner = partner;
  return next();
};

const router = Router();

// ==== Admin Routes ====

// Get all affiliate partners (admin only)
router.get('/partners', isAdmin, async (req, res) => {
  try {
    const status = req.query.status as string | undefined;
    const partners = await storage.getAffiliatePartners(status);
    res.json(partners);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Get affiliate partner by ID (admin only)
router.get('/partners/:id', isAdmin, async (req, res) => {
  try {
    const partner = await storage.getAffiliatePartner(parseInt(req.params.id));
    if (!partner) {
      return res.status(404).json({ message: 'Affiliate partner not found' });
    }
    res.json(partner);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Create new affiliate partner (admin only)
router.post('/partners', isAdmin, async (req, res) => {
  try {
    const partnerData = insertAffiliatePartnerSchema.parse(req.body);
    
    // Check if email already exists
    const existingPartner = await storage.getAffiliatePartnerByEmail(partnerData.email);
    if (existingPartner) {
      return res.status(400).json({ message: 'Email already in use' });
    }
    
    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(partnerData.password, salt);
    
    const newPartner = await storage.createAffiliatePartner({
      ...partnerData,
      password: hashedPassword
    });
    
    res.status(201).json(newPartner);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: err.errors });
    }
    res.status(500).json({ message: err.message });
  }
});

// Update affiliate partner (admin only)
router.patch('/partners/:id', isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const partner = await storage.getAffiliatePartner(id);
    
    if (!partner) {
      return res.status(404).json({ message: 'Affiliate partner not found' });
    }
    
    // If password is being updated, hash it
    if (req.body.password) {
      const salt = await bcrypt.genSalt(10);
      req.body.password = await bcrypt.hash(req.body.password, salt);
    }
    
    const updatedPartner = await storage.updateAffiliatePartner(id, req.body);
    res.json(updatedPartner);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Approve affiliate partner (admin only)
router.post('/partners/:id/approve', isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const partner = await storage.getAffiliatePartner(id);
    
    if (!partner) {
      return res.status(404).json({ message: 'Affiliate partner not found' });
    }
    
    const approvedPartner = await storage.approveAffiliatePartner(id, req.user.id);
    res.json(approvedPartner);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Get all coupons (admin only)
router.get('/coupons', isAdmin, async (req, res) => {
  try {
    const partnerId = req.query.partnerId ? parseInt(req.query.partnerId as string) : undefined;
    const isActive = req.query.isActive !== undefined ? req.query.isActive === 'true' : undefined;
    
    const coupons = await storage.getAffiliateCoupons(partnerId, isActive);
    res.json(coupons);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Create new coupon (admin only)
router.post('/coupons', isAdmin, async (req, res) => {
  try {
    const couponData = insertAffiliateCouponSchema.parse(req.body);
    
    // Check if partner exists
    const partner = await storage.getAffiliatePartner(couponData.partnerId);
    if (!partner) {
      return res.status(400).json({ message: 'Affiliate partner not found' });
    }
    
    // Check if code already exists
    const existingCoupon = await storage.getAffiliateCouponByCode(couponData.code);
    if (existingCoupon) {
      return res.status(400).json({ message: 'Coupon code already exists' });
    }
    
    const newCoupon = await storage.createAffiliateCoupon(couponData);
    res.status(201).json(newCoupon);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: err.errors });
    }
    res.status(500).json({ message: err.message });
  }
});

// Get coupon by ID (admin only)
router.get('/coupons/:id', isAdmin, async (req, res) => {
  try {
    const coupon = await storage.getAffiliateCoupon(parseInt(req.params.id));
    if (!coupon) {
      return res.status(404).json({ message: 'Coupon not found' });
    }
    res.json(coupon);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Update coupon (admin only)
router.patch('/coupons/:id', isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const coupon = await storage.getAffiliateCoupon(id);
    
    if (!coupon) {
      return res.status(404).json({ message: 'Coupon not found' });
    }
    
    const updatedCoupon = await storage.updateAffiliateCoupon(id, req.body);
    res.json(updatedCoupon);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Get all affiliate transactions (admin only)
router.get('/transactions', isAdmin, async (req, res) => {
  try {
    const partnerId = parseInt(req.query.partnerId as string);
    
    if (!partnerId) {
      return res.status(400).json({ message: 'Partner ID is required' });
    }
    
    const transactions = await storage.getAffiliateTransactions(partnerId);
    res.json(transactions);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Update transaction status (admin only)
router.patch('/transactions/:id/status', isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status } = req.body;
    
    if (!status) {
      return res.status(400).json({ message: 'Status is required' });
    }
    
    const transaction = await storage.getAffiliateTransaction(id);
    if (!transaction) {
      return res.status(404).json({ message: 'Transaction not found' });
    }
    
    const updatedTransaction = await storage.updateAffiliateTransactionStatus(id, status);
    res.json(updatedTransaction);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Create payment for partner (admin only)
router.post('/payments', isAdmin, async (req, res) => {
  try {
    const paymentData = insertAffiliatePaymentSchema.parse(req.body);
    
    // Check if partner exists
    const partner = await storage.getAffiliatePartner(paymentData.partnerId);
    if (!partner) {
      return res.status(400).json({ message: 'Affiliate partner not found' });
    }
    
    const newPayment = await storage.createAffiliatePayment(paymentData);
    
    // Update transactions status to 'paid' if transactions are provided
    if (paymentData.transactions && paymentData.transactions.length > 0) {
      for (const transactionId of paymentData.transactions) {
        await storage.updateAffiliateTransactionStatus(transactionId, 'paid');
      }
    }
    
    res.status(201).json(newPayment);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: err.errors });
    }
    res.status(500).json({ message: err.message });
  }
});

// Get payments for partner (admin only)
router.get('/payments', isAdmin, async (req, res) => {
  try {
    const partnerId = parseInt(req.query.partnerId as string);
    
    if (!partnerId) {
      return res.status(400).json({ message: 'Partner ID is required' });
    }
    
    const payments = await storage.getAffiliatePayments(partnerId);
    res.json(payments);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Update payment status (admin only)
router.patch('/payments/:id/status', isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status, reference } = req.body;
    
    if (!status) {
      return res.status(400).json({ message: 'Status is required' });
    }
    
    const payment = await storage.getAffiliatePayment(id);
    if (!payment) {
      return res.status(404).json({ message: 'Payment not found' });
    }
    
    const updatedPayment = await storage.updateAffiliatePaymentStatus(id, status, reference);
    res.json(updatedPayment);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// ==== Public Routes ====

// Partner application/registration (public)
router.post('/apply', async (req, res) => {
  try {
    const partnerData = insertAffiliatePartnerSchema.parse(req.body);
    
    // Check if email already exists
    const existingPartner = await storage.getAffiliatePartnerByEmail(partnerData.email);
    if (existingPartner) {
      return res.status(400).json({ message: 'Email already in use' });
    }
    
    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(partnerData.password, salt);
    
    const newPartner = await storage.createAffiliatePartner({
      ...partnerData,
      password: hashedPassword,
      status: 'pending' // Always start as pending
    });
    
    // Remove password from response
    const { password, ...partnerResponse } = newPartner;
    
    res.status(201).json(partnerResponse);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: err.errors });
    }
    res.status(500).json({ message: err.message });
  }
});

// Partner login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }
    
    const partner = await storage.getAffiliatePartnerByEmail(email);
    if (!partner) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }
    
    // Check if partner is active
    if (partner.status !== 'active') {
      return res.status(403).json({ 
        message: 'Your account is not active yet. Please wait for admin approval.',
        status: partner.status
      });
    }
    
    // Verify password
    const isMatch = await bcrypt.compare(password, partner.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }
    
    // Remove password from response
    const { password: _, ...partnerResponse } = partner;
    
    // Set session
    req.session.affiliatePartner = partnerResponse;
    
    res.json(partnerResponse);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Partner logout
router.post('/logout', (req, res) => {
  try {
    if (req.session.affiliatePartner) {
      delete req.session.affiliatePartner;
    }
    res.status(200).json({ message: 'Logged out successfully' });
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Get current partner
router.get('/me', isAffiliatePartner, (req, res) => {
  try {
    const partner = req.affiliatePartner;
    
    // Remove password from response
    const { password, ...partnerResponse } = partner;
    
    res.json(partnerResponse);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// ==== Partner Routes ====

// Get partner's coupons
router.get('/partners/:partnerId/coupons', isAffiliatePartner, async (req, res) => {
  try {
    const partnerId = parseInt(req.params.partnerId);
    
    // Check if partner is requesting their own data
    if (req.affiliatePartner.id !== partnerId && !req.user?.role === 'admin') {
      return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
    }
    
    const coupons = await storage.getAffiliateCoupons(partnerId);
    res.json(coupons);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Create new coupon for partner
router.post('/partners/:partnerId/coupons', isAffiliatePartner, async (req, res) => {
  try {
    const partnerId = parseInt(req.params.partnerId);
    
    // Check if partner is requesting their own data
    if (req.affiliatePartner.id !== partnerId && !req.user?.role === 'admin') {
      return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
    }
    
    // Generate a unique coupon code if not provided
    if (!req.body.code) {
      req.body.code = `${req.affiliatePartner.name.substring(0, 3).toUpperCase()}-${nanoid(8).toUpperCase()}`;
    }
    
    const couponData = {
      ...req.body,
      partnerId
    };
    
    // Validate data
    const validatedData = insertAffiliateCouponSchema.parse(couponData);
    
    // Check if code already exists
    const existingCoupon = await storage.getAffiliateCouponByCode(validatedData.code);
    if (existingCoupon) {
      return res.status(400).json({ message: 'Coupon code already exists' });
    }
    
    const newCoupon = await storage.createAffiliateCoupon(validatedData);
    res.status(201).json(newCoupon);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: err.errors });
    }
    res.status(500).json({ message: err.message });
  }
});

// Get partner's referrals
router.get('/partners/:partnerId/referrals', isAffiliatePartner, async (req, res) => {
  try {
    const partnerId = parseInt(req.params.partnerId);
    
    // Check if partner is requesting their own data
    if (req.affiliatePartner.id !== partnerId && !req.user?.role === 'admin') {
      return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
    }
    
    const referrals = await storage.getAffiliateReferrals(partnerId);
    res.json(referrals);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Create new referral for partner
router.post('/partners/:partnerId/referrals', isAffiliatePartner, async (req, res) => {
  try {
    const partnerId = parseInt(req.params.partnerId);
    
    // Check if partner is requesting their own data
    if (req.affiliatePartner.id !== partnerId && !req.user?.role === 'admin') {
      return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
    }
    
    // Generate a unique referral code if not provided
    if (!req.body.referralCode) {
      req.body.referralCode = `REF-${nanoid(8).toUpperCase()}`;
    }
    
    // Generate a referral URL if not provided
    if (!req.body.referralUrl) {
      req.body.referralUrl = `https://bondquest.app/ref/${req.body.referralCode}`;
    }
    
    const referralData = {
      ...req.body,
      partnerId
    };
    
    // Validate data
    const validatedData = insertAffiliateReferralSchema.parse(referralData);
    
    const newReferral = await storage.createAffiliateReferral(validatedData);
    res.status(201).json(newReferral);
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: err.errors });
    }
    res.status(500).json({ message: err.message });
  }
});

// Get partner's transactions
router.get('/partners/:partnerId/transactions', isAffiliatePartner, async (req, res) => {
  try {
    const partnerId = parseInt(req.params.partnerId);
    
    // Check if partner is requesting their own data
    if (req.affiliatePartner.id !== partnerId && !req.user?.role === 'admin') {
      return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
    }
    
    const transactions = await storage.getAffiliateTransactions(partnerId);
    res.json(transactions);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Get partner's payments
router.get('/partners/:partnerId/payments', isAffiliatePartner, async (req, res) => {
  try {
    const partnerId = parseInt(req.params.partnerId);
    
    // Check if partner is requesting their own data
    if (req.affiliatePartner.id !== partnerId && !req.user?.role === 'admin') {
      return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
    }
    
    const payments = await storage.getAffiliatePayments(partnerId);
    res.json(payments);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// ==== Coupon Routes for Customers ====

// Validate coupon
router.post('/validate-coupon', isAuthenticated, async (req, res) => {
  try {
    const { code } = req.body;
    
    if (!code) {
      return res.status(400).json({ message: 'Coupon code is required' });
    }
    
    const coupon = await storage.getAffiliateCouponByCode(code);
    
    if (!coupon) {
      return res.status(404).json({ message: 'Coupon not found' });
    }
    
    // Check if coupon is active
    if (!coupon.isActive) {
      return res.status(400).json({ message: 'Coupon is not active' });
    }
    
    // Check if coupon has expired
    const now = new Date();
    if (coupon.endDate < now) {
      return res.status(400).json({ message: 'Coupon has expired' });
    }
    
    // Check if coupon has reached max uses
    if (coupon.maxUses && coupon.currentUses >= coupon.maxUses) {
      return res.status(400).json({ message: 'Coupon has reached maximum uses' });
    }
    
    // Return coupon details (excluding sensitive information)
    const { partnerId, maxUses, currentUses, ...couponDetails } = coupon;
    
    res.json({
      valid: true,
      coupon: couponDetails
    });
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Apply coupon
router.post('/apply-coupon', isAuthenticated, async (req, res) => {
  try {
    const { code, subscriptionId } = req.body;
    
    if (!code || !subscriptionId) {
      return res.status(400).json({ message: 'Coupon code and subscription ID are required' });
    }
    
    const coupon = await storage.getAffiliateCouponByCode(code);
    
    if (!coupon) {
      return res.status(404).json({ message: 'Coupon not found' });
    }
    
    // Check if coupon is active
    if (!coupon.isActive) {
      return res.status(400).json({ message: 'Coupon is not active' });
    }
    
    // Check if coupon has expired
    const now = new Date();
    if (coupon.endDate < now) {
      return res.status(400).json({ message: 'Coupon has expired' });
    }
    
    // Check if coupon has reached max uses
    if (coupon.maxUses && coupon.currentUses >= coupon.maxUses) {
      return res.status(400).json({ message: 'Coupon has reached maximum uses' });
    }
    
    // Increment coupon uses
    await storage.incrementCouponUses(coupon.id);
    
    // Create transaction record
    const subscription = await storage.getUserSubscription(parseInt(subscriptionId));
    if (!subscription) {
      return res.status(404).json({ message: 'Subscription not found' });
    }
    
    const tier = await storage.getSubscriptionTier(subscription.tierId);
    if (!tier) {
      return res.status(404).json({ message: 'Subscription tier not found' });
    }
    
    // Calculate commission
    let discountAmount = 0;
    let originalAmount = Number(tier.price);
    
    if (coupon.type === 'percentage') {
      discountAmount = originalAmount * (Number(coupon.value) / 100);
    } else if (coupon.type === 'fixed') {
      discountAmount = Number(coupon.value);
    } else if (coupon.type === 'free_trial') {
      // Free trial doesn't generate immediate commission
      discountAmount = 0;
    }
    
    // Calculate commission (typically a percentage of the remaining amount)
    const remainingAmount = originalAmount - discountAmount;
    const commissionAmount = remainingAmount * (Number(coupon.partnerId) / 100);
    
    // Create transaction record
    const transaction = await storage.createAffiliateTransaction({
      partnerId: coupon.partnerId,
      userId: req.user.id,
      subscriptionId: subscription.id,
      couponId: coupon.id,
      amount: remainingAmount,
      commissionAmount,
      currency: 'USD',
      status: 'pending',
      transactionType: 'new_subscription'
    });
    
    res.json({
      success: true,
      discount: {
        type: coupon.type,
        value: coupon.value,
        discountAmount
      },
      transaction
    });
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

// Track referral click
router.get('/ref/:code', async (req, res) => {
  try {
    const { code } = req.params;
    
    const referral = await storage.getAffiliateReferralByCode(code);
    
    if (!referral) {
      return res.status(404).json({ message: 'Referral not found' });
    }
    
    // Increment click count
    await storage.incrementReferralClick(referral.id);
    
    // Redirect to appropriate page or return success
    // In a real implementation, you might redirect to a landing page
    res.json({ success: true, redirectUrl: '/signup?ref=' + code });
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
});

export default router;